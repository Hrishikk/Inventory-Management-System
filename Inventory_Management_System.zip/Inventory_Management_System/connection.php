<?php
   $link=mysqli_connect("localhost","root","","Inventory_management") or die(mysqli_error($link));
?>